#pragma once
#include "Shape2D.h"
class Collider
{
	Shape2D* shape;
};

